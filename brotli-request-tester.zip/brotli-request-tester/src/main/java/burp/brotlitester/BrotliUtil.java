package burp.brotlitester;

import burp.api.montoya.core.ByteArray;
import burp.api.montoya.http.message.requests.HttpRequest;

import com.aayushatharva.brotli4j.Brotli4jLoader;
import com.aayushatharva.brotli4j.encoder.Encoder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Brotli-related helpers. Only the request BODY is compressed; the request
 * line and all headers stay plaintext, which is exactly how Content-Encoding
 * is defined to work.
 */
public final class BrotliUtil {

    private BrotliUtil() {
    }

    /** Loads the native brotli library. Safe to call many times. */
    public static void ensureReady() {
        Brotli4jLoader.ensureAvailability();
    }

    public static byte[] compress(byte[] data) throws IOException {
        return Encoder.compress(data);
    }

    /** A tiny, harmless JSON body used when the original request has none. */
    private static final byte[] PROBE_BODY =
            "{\"brotliProbe\":true}".getBytes(StandardCharsets.UTF_8);

    /** The original request's Content-Encoding, or "-" if it had none. */
    public static String originalContentEncoding(HttpRequest req) {
        String v = req.headerValue("Content-Encoding");
        return (v == null || v.isEmpty()) ? "-" : v;
    }

    /**
     * Returns a copy of {@code original} whose body is a VALID Brotli stream and
     * whose Content-Encoding header is set to "br". Any pre-existing
     * Content-Encoding (gzip, deflate, even an existing br) is replaced so the
     * server is unambiguously asked to Brotli-decode the body.
     *
     * If the request has no body and {@code injectBodyIfEmpty} is true, a tiny
     * JSON probe body is inserted so that body-parsing middleware actually runs
     * the Brotli decoder (an empty body is often skipped). This is a VALID
     * stream, not a malformed/exploit one: it tells you whether the endpoint
     * decodes Brotli, not whether the decoder is the vulnerable build.
     *
     * Montoya recalculates Content-Length automatically when the body changes.
     */
    public static HttpRequest toBrotliRequest(HttpRequest original,
                                              boolean injectBodyIfEmpty)
            throws IOException {
        ensureReady();

        HttpRequest req = original;
        byte[] body = original.body().getBytes();

        if (body.length == 0 && injectBodyIfEmpty) {
            body = PROBE_BODY;
            if (!req.hasHeader("Content-Type")) {
                req = req.withAddedHeader("Content-Type", "application/json");
            }
        }

        byte[] compressed = compress(body);

        if (req.hasHeader("Content-Encoding")) {
            req = req.withRemovedHeader("Content-Encoding");
        }

        req = req.withBody(ByteArray.byteArray(compressed))
                 .withAddedHeader("Content-Encoding", "br");

        return req;
    }
}
