package burp.brotlitester;

import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.http.message.HttpRequestResponse;
import burp.api.montoya.http.message.requests.HttpRequest;
import burp.api.montoya.http.message.responses.HttpResponse;
import burp.api.montoya.proxy.ProxyHttpRequestResponse;
import burp.api.montoya.ui.contextmenu.ContextMenuEvent;
import burp.api.montoya.ui.contextmenu.ContextMenuItemsProvider;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Brotli Request Tester
 *
 * Right-click one or more requests (Proxy history, Site map, Repeater, etc.),
 * choose "Brotli: test request support", and the extension:
 *   1. Brotli-compresses the body of each request.
 *   2. Sets Content-Encoding: br (Content-Length is auto-fixed by Montoya).
 *   3. Sends it, optionally alongside the original uncompressed request.
 *   4. Compares the two responses and logs a verdict in the "Brotli Tester" tab.
 */
public class BrotliTester implements BurpExtension, ContextMenuItemsProvider {

    private MontoyaApi api;
    private DefaultTableModel model;
    private JCheckBox sendBaseline;
    private JCheckBox onlyInScope;
    private JCheckBox injectBody;

    // The exact Brotli-encoded request behind each results row (null for
    // skipped/error/note rows), so a row can be replayed in Repeater.
    private final List<HttpRequest> rowRequests = new ArrayList<>();

    @Override
    public void initialize(MontoyaApi api) {
        this.api = api;
        api.extension().setName("Brotli Request Tester");

        try {
            BrotliUtil.ensureReady();
            api.logging().logToOutput("brotli4j native library loaded OK.");
        } catch (Throwable t) {
            api.logging().logToError(
                "Could not load brotli4j native library. Make sure the jar was "
                + "built as the shaded '-all.jar' and includes the native artifact "
                + "for your OS/arch. Error: " + t);
        }

        buildUi();
        api.userInterface().registerContextMenuItemsProvider(this);
        api.logging().logToOutput(
            "Brotli Request Tester loaded. Right-click a request to test it.");
    }

    // ---------------------------------------------------------------- UI

    private void buildUi() {
        JPanel panel = new JPanel(new BorderLayout());

        model = new DefaultTableModel(
                new Object[]{"Host", "Method", "Path", "Orig CE", "Baseline",
                             "Brotli", "Powered-By", "Exposed", "Verdict"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Right-click a row -> send its Brotli request to Repeater to validate.
        JPopupMenu popup = new JPopupMenu();
        JMenuItem toRepeater = new JMenuItem(
                "Send Brotli request to Repeater (to validate)");
        toRepeater.addActionListener(e -> {
            for (int viewRow : table.getSelectedRows()) {
                int row = table.convertRowIndexToModel(viewRow);
                if (row >= 0 && row < rowRequests.size()) {
                    HttpRequest r = rowRequests.get(row);
                    if (r != null) {
                        api.repeater().sendToRepeater(
                                r, "br " + r.pathWithoutQuery());
                    }
                }
            }
        });
        popup.add(toRepeater);
        table.setComponentPopupMenu(popup);
        // Make a right-click select the row under the cursor first.
        table.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e)  { selectUnderMouse(e); }
            @Override public void mouseReleased(MouseEvent e) { selectUnderMouse(e); }
            private void selectUnderMouse(MouseEvent e) {
                if (!e.isPopupTrigger()) return;
                int r = table.rowAtPoint(e.getPoint());
                if (r >= 0 && !table.isRowSelected(r)) {
                    table.setRowSelectionInterval(r, r);
                }
            }
        });

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        onlyInScope = new JCheckBox(
                "Only test in-scope requests (uses Target > Scope)", true);
        injectBody = new JCheckBox(
                "Inject a probe body when a request has none", true);
        sendBaseline = new JCheckBox(
                "Also send the uncompressed request as a baseline", true);
        JButton scan = new JButton("Scan Proxy history");
        scan.setToolTipText("Test every unique endpoint in Proxy history, "
                + "all methods, respecting the in-scope checkbox.");
        scan.addActionListener(e ->
                new Thread(this::scanHistory, "brotli-scan").start());

        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> { model.setRowCount(0); rowRequests.clear(); });

        top.add(onlyInScope);
        top.add(injectBody);
        top.add(sendBaseline);
        top.add(scan);
        top.add(clear);

        panel.add(top, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        api.userInterface().registerSuiteTab("Brotli Tester", panel);
    }

    // ------------------------------------------------------- context menu

    @Override
    public List<Component> provideMenuItems(ContextMenuEvent event) {
        List<HttpRequestResponse> targets = collectTargets(event);
        if (targets.isEmpty()) {
            return null;
        }

        List<Component> items = new ArrayList<>();

        JMenuItem test = new JMenuItem(
                "Brotli: test request support (log results)");
        test.addActionListener(e ->
                new Thread(() -> {
                    for (HttpRequestResponse rr : targets) {
                        HttpRequest req = rr.request();
                        if (onlyInScope.isSelected()
                                && !api.scope().isInScope(req.url())) {
                            addRow(req, "-", null, null, "-",
                                    "SKIPPED (out of scope)", null);
                            continue;
                        }
                        testOne(req);
                    }
                }, "brotli-tester").start());
        items.add(test);

        JMenuItem repeater = new JMenuItem(
                "Brotli: send compressed copy to Repeater");
        repeater.addActionListener(e -> {
            for (HttpRequestResponse rr : targets) {
                try {
                    HttpRequest mod = BrotliUtil.toBrotliRequest(
                            rr.request(), injectBody.isSelected());
                    api.repeater().sendToRepeater(
                            mod, "br " + rr.request().pathWithoutQuery());
                } catch (Exception ex) {
                    api.logging().logToError("Compress failed: " + ex);
                }
            }
        });
        items.add(repeater);

        return items;
    }

    private List<HttpRequestResponse> collectTargets(ContextMenuEvent event) {
        List<HttpRequestResponse> list =
                new ArrayList<>(event.selectedRequestResponses());
        if (list.isEmpty() && event.messageEditorRequestResponse().isPresent()) {
            list.add(event.messageEditorRequestResponse().get().requestResponse());
        }
        return list;
    }

    // ------------------------------------------------------------- logic

    /**
     * Sweeps Proxy history and tests every unique endpoint, ALL HTTP methods
     * (including bodyless GETs). Honours the "only in-scope" checkbox.
     * Endpoints are de-duplicated by METHOD + host + path, so the same endpoint
     * hit 50 times is tested once.
     */
    private void scanHistory() {
        List<ProxyHttpRequestResponse> history = api.proxy().history();
        Set<String> seen = new HashSet<>();
        int tested = 0;
        int skippedScope = 0;

        for (ProxyHttpRequestResponse item : history) {
            HttpRequest req = item.request();

            if (onlyInScope.isSelected() && !api.scope().isInScope(req.url())) {
                skippedScope++;
                continue;
            }

            String key = req.method() + " "
                    + req.httpService().host() + req.pathWithoutQuery();
            if (!seen.add(key)) {
                continue;                     // already tested this endpoint
            }

            testOne(req);
            tested++;
        }

        api.logging().logToOutput(String.format(
                "Brotli history scan done: tested %d unique endpoint(s); "
                + "skipped %d out-of-scope.", tested, skippedScope));

        if (tested == 0) {
            addRow(null, "-", null, null, "-",
                    "Nothing to test (checked " + history.size()
                    + " history items)", null);
        }
    }

    private void testOne(HttpRequest original) {
        String origCE = BrotliUtil.originalContentEncoding(original);
        try {
            HttpRequest brotliReq =
                    BrotliUtil.toBrotliRequest(original, injectBody.isSelected());
            HttpResponse brotliResp = api.http().sendRequest(brotliReq).response();

            HttpResponse baseResp = null;
            if (sendBaseline.isSelected()) {
                baseResp = api.http().sendRequest(original).response();
            }

            Integer bStatus    = brotliResp == null ? null : (int) brotliResp.statusCode();
            Integer baseStatus = baseResp   == null ? null : (int) baseResp.statusCode();
            String poweredBy   = fingerprint(brotliResp);

            addRow(original, origCE, baseStatus, bStatus, poweredBy,
                    verdict(bStatus, baseStatus), brotliReq);
        } catch (Throwable t) {
            api.logging().logToError("Test failed for " + original.url() + " : " + t);
            addRow(original, origCE, null, null, "-",
                    "ERROR: " + t.getMessage(), null);
        }
    }

    /**
     * Pulls framework hints from the response. X-Powered-By: Express is the
     * clearest signal for the Node2Shell inbound path (Express 5 + body-parser 2
     * decompress br request bodies by default). Server is shown otherwise.
     */
    private String fingerprint(HttpResponse resp) {
        if (resp == null) return "-";
        String powered = resp.headerValue("X-Powered-By");
        if (powered != null && !powered.isEmpty()) return powered;
        String server = resp.headerValue("Server");
        if (server != null && !server.isEmpty()) return server;
        return "-";
    }

    /**
     * Verdict framed around Node2Shell (CVE-2026-111497) EXPOSURE, not proof.
     * We send a VALID Brotli body, so a success means the endpoint decodes
     * Brotli request bodies and therefore reaches the decoder. It does NOT prove
     * the Node/Bun build is the vulnerable one -- confirm that from the runtime
     * version. A 415/501, or a 400 where the baseline succeeded, means the
     * server did not Brotli-decode the body, so this path is not exposed.
     */
    private String verdict(Integer b, Integer base) {
        if (b == null) return "No response / error";
        if (b == 415)  return "Not exposed (415 rejects br)";
        if (b == 501)  return "Not exposed (501 rejects br)";

        if (base != null) {
            if (b < 300 && base < 300)
                return "DECODES br -> reaches decoder (verify Node version)";
            if (base < 300 && b >= 400)
                return "Not decoding br (" + b + " vs baseline " + base + ")";
            if (b.equals(base))
                return "Inconclusive (same as baseline " + b + ")";
            return "Check manually (br " + b + " / base " + base + ")";
        }

        if (b < 300)  return "DECODES br -> reaches decoder (verify Node version)";
        if (b == 400) return "Not decoding br (400)";
        return "Status " + b + " (check manually)";
    }

    /**
     * Quick Yes/No/Maybe for the "Exposed" column. "Yes" means the endpoint
     * decodes Brotli and so REACHES the vulnerable decoder -- it is NOT a
     * confirmation that the runtime is the vulnerable build. Confirm that from
     * the Node/Bun version (fixed: 22.23.4, 24.22.1, 26.12.1; Bun 1.4.4).
     */
    private String exposedFlag(String verdict) {
        if (verdict == null) return "?";
        if (verdict.startsWith("DECODES br")) return "Yes";
        if (verdict.startsWith("Not exposed")
                || verdict.startsWith("Not decoding")) return "No";
        if (verdict.startsWith("SKIPPED")
                || verdict.startsWith("Nothing")
                || verdict.startsWith("ERROR")) return "-";
        return "Maybe";
    }

    private void addRow(HttpRequest req, String origCE, Integer base, Integer b,
                        String poweredBy, String verdict,
                        HttpRequest brotliToReplay) {
        SwingUtilities.invokeLater(() -> {
            rowRequests.add(brotliToReplay);   // keep index-aligned with rows
            model.addRow(new Object[]{
                    req == null ? "-" : req.httpService().host(),
                    req == null ? "-" : req.method(),
                    req == null ? "-" : req.pathWithoutQuery(),
                    origCE,
                    base == null ? "-" : base,
                    b    == null ? "-" : b,
                    poweredBy,
                    exposedFlag(verdict),
                    verdict
            });
        });
    }
}
