# Brotli Request Tester (Burp Suite extension)

Maps which of your in-scope endpoints **decompress a `Content-Encoding: br`
request body**, i.e. which routes reach a server-side Brotli decoder with
attacker-controlled input. This is the inbound exposure surface for
**Node2Shell / CVE-2026-111497**, the out-of-bounds write in the Brotli decoder
bundled with Node.js (also Bun). Only the body is compressed; the request line
and headers stay plaintext, which is how `Content-Encoding` is defined to work.

## Important: "Exposed" is not "Vulnerable"

There is no automatic "Vulnerable: Yes/No" column, on purpose. A trustworthy
yes/no needs either the runtime version (which HTTP probing can't reliably read)
or firing the actual malformed-stream exploit (a crash/RCE primitive you don't
want aimed at your own services). So the extension answers the question it *can*
answer safely:

- The **Exposed** column is **Yes / No / Maybe**:
  - **Yes**  = the endpoint decoded a valid Brotli body, so it REACHES the
    decoder. This is the attack surface, not a confirmed exploit.
  - **No**   = the server rejected or didn't Brotli-decode the body.
  - **Maybe**= ambiguous; validate manually.

A patched Node still decodes valid Brotli fine (the fix only rejects *malformed*
streams), so "Yes" appears on patched and unpatched hosts alike. **Confirm real
vulnerability from the runtime version** on the service you own.

Fixed versions: Node.js **22.23.4**, **24.22.1**, **26.12.1**; Bun **1.4.4**.
Anything older on those lines that decodes untrusted Brotli is vulnerable.

To validate a specific finding by hand: **right-click its row in the Brotli
Tester tab -> "Send Brotli request to Repeater"**, then inspect/modify it there.

This tool deliberately ships **no malformed/crash/RCE payload** — only the
valid-stream exposure probe.

## What it does

For each request it:

1. Brotli-compresses the body (injecting a tiny JSON probe body if the request
   has none, so body-parsing middleware actually runs the decoder).
2. Replaces any existing `Content-Encoding` (gzip/deflate/br) with `br` and sets
   it if absent. Content-Length is recalculated automatically.
3. Sends it, and (optionally) the original uncompressed request as a baseline.
4. Records the original Content-Encoding, the `X-Powered-By`/`Server`
   fingerprint, both status codes, and a verdict in the **Brotli Tester** tab.

`X-Powered-By: Express` in the results is the strongest hint for the Node2Shell
inbound path (Express 5 + body-parser 2 decompress br bodies by default).

## Build

You need a JDK (17+) and internet access to Maven Central.

```bash
cd brotli-request-tester
./gradlew shadowJar        # on Windows: gradlew.bat shadowJar
```

If you don't have the Gradle wrapper files, run `gradle wrapper` once first
(requires a system Gradle), or just run `gradle shadowJar`.

The extension jar is created at:

```
build/libs/brotli-request-tester-all.jar
```

Load **that** `-all.jar` (the shaded one) — it bundles brotli4j and its native
libraries. The plain jar will not work.

## Install in Burp

1. **Extensions** → **Installed** → **Add**.
2. Extension type: **Java**.
3. Select `build/libs/brotli-request-tester-all.jar`.
4. Check the **Output** tab — you should see
   `brotli4j native library loaded OK.`

## Use

1. In **Proxy → HTTP history** (or Site map / Repeater), select one or more
   requests. Multi-select works, so you can probe many endpoints at once.
2. Right-click → **Brotli: test request support (log results)**.
3. Open the **Brotli Tester** tab to read the verdicts.
4. Or right-click → **Brotli: send compressed copy to Repeater** to inspect a
   single compressed request by hand.

## Reading the verdict

| Verdict | Meaning |
|---|---|
| `DECODES br -> reaches decoder (verify Node version)` | Endpoint decoded a valid Brotli body. On the Node2Shell attack surface; confirm the runtime version. |
| `Not exposed (415 rejects br)` / `(501 rejects br)` | Server explicitly refuses the encoding — this path doesn't reach the decoder. |
| `Not decoding br (400 ...)` | Server didn't Brotli-decode (tried to parse raw bytes, or rejected). |
| `Inconclusive` / `Check manually` | Ambiguous (e.g. endpoint always returns the same status) — open the responses and verify. |

The verdict is a heuristic about *decoding behaviour*, not vulnerability. For
anything unclear, send the request to Repeater and look at the actual response.

## Two ways to use it

**Manual (right-click):** select one or more requests anywhere (Proxy history,
Site map, Repeater) and right-click -> "Brotli: test request support". Good for
spot-checking specific endpoints.

**Sweep (Scan Proxy history button):** open the "Brotli Tester" tab and click
**Scan Proxy history**. It walks your whole Proxy HTTP history across **all HTTP
methods** (including bodyless GETs — a probe body is injected), de-duplicates by
METHOD + host + path (so an endpoint hit 50 times is tested once), and tests
each. With the in-scope box ticked it only touches endpoints in your
Target > Scope. This is the "which of my endpoints decode Brotli?" sweep.

## Scope

By default **"Only test in-scope requests"** is ticked, so the extension will
only send requests whose URL is in your **Target > Scope**. Anything outside
scope is logged as `SKIPPED (out of scope)` and never sent. Untick the box to
test any request you select, regardless of scope. (The "send compressed copy to
Repeater" action is manual and always available — it only stages a request, it
doesn't send it.)

## Notes

- Testing a GET with an empty body is pointless — pick requests that carry a
  JSON/form body (POST/PUT/PATCH).
- `Content-Encoding: br` on a request means "the body I'm sending is Brotli".
  Don't confuse it with `Accept-Encoding: br`, which only asks the server to
  compress its *response*.
- Only test applications you are authorised to test.
